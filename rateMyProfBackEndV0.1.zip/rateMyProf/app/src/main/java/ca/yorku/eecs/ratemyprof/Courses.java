package ca.yorku.eecs.ratemyprof;

public class Courses
{
    private String courname ;
    private String courcode;
    private Rate Rate;
    public Courses(String courname , String courcode){
        this.courname = courname;
        this.courcode = courcode;
    }

    public void setCourseName(String courname){
        this.courname = courname;
    }

    public void seCourseCode (String courcode){
        this.courcode = courcode;

    }

    public String getCourseName(){
        return courname;
    }

    public String getCourCode(){
        return courcode;
    }


}
