package ca.yorku.eecs.ratemyprof;

import java.util.ArrayList;

public class Main
{
    @SuppressWarnings("MismatchedQueryAndUpdateOfCollection")
    public static void main(String[] args)
    {

        ArrayList<Courses> courses = new ArrayList<Courses>();
        ArrayList<Rate> rete = new ArrayList<Rate>();
        ArrayList<Prof> Prof = new ArrayList<Prof>();
        Prof.add(new Prof("LAST","first"));
        Prof.get(0).addCourse(new Courses("EECS","1001"));
        Prof.get(0).addRate(new Rate(5,5,5,5));
    }
}
