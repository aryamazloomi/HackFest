package ca.yorku.eecs.ratemyprof;

public class Rate
{
    private double overall;
    private double test;
    private double assign;
    private double friend;

    public Rate() {}
    public Rate(double overall , double test, double assign, double friend) {
        this.overall = overall;
        this.test = test;
        this.assign = assign;
        this.friend = friend;
    }

    public double getOverall()
    {
        return overall;
    }

    public void setOverall(double overall)
    {
        this.overall = overall;
    }

    public double getTest()
    {
        return test;
    }

    public void setTest(double test)
    {
        this.test = test;
    }

    public double getAssign()
    {
        return assign;
    }

    public void setAssign(double assign)
    {
        this.assign = assign;
    }

    public double getFriend()
    {
        return friend;
    }

    public void setFriend(double friend)
    {
        this.friend = friend;
    }
}
